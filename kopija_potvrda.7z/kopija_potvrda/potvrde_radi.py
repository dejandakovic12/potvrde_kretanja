import csv, docx


def main():
    with open(
        "C:\\Users\\Dejan\\Desktop\\radnici.csv", "r", encoding="utf8"
    ) as read_obj:
        csv_data = csv.reader(read_obj, delimiter=";")
        for row in csv_data:
            skup = {
                "IME": row[0],
                "PRE": row[1],
                "BRLK": row[2],
                "OD": row[3],
                "DO": row[4],
                "RMJESTO": row[5],
                "BRPOT": row[6],
                "RELACIJA": row[7],
            }

            doc = docx.Document("C:\\Users\\Dejan\\Desktop\\obrazac.docx")
            for i in skup:
                for p in doc.paragraphs:
                    if p.text.find(i) >= 0:
                        p.text = p.text.replace(i, skup[i])

            doc.save(
                "C:\\Users\\Dejan\\Desktop\\Auto potvrde\\"
                + row[0]
                + " "
                + row[1]
                + ".docx"
            )


if __name__ == "__main__":
    main()
